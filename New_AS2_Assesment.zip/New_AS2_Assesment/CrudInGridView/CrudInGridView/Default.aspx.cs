﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace CrudInGridView
{
    public partial class Default : System.Web.UI.Page
    {
        string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Integrated Security=true;Initial Catalog=StudentDB"; // perhaps gonan have to change the value to your local when using BAK 
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                PopulateGridview();
            }
        }

        void PopulateGridview()
        {
            DataTable dtbl = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM StudentRecords", sqlCon);
                sqlDa.Fill(dtbl);
            }
            if (dtbl.Rows.Count > 0)
            {
                gvStudentRecords.DataSource = dtbl;
                gvStudentRecords.DataBind();
            }
            else
            {
                dtbl.Rows.Add(dtbl.NewRow());
                gvStudentRecords.DataSource = dtbl;
                gvStudentRecords.DataBind();
                gvStudentRecords.Rows[0].Cells.Clear();
                gvStudentRecords.Rows[0].Cells.Add(new TableCell());
                gvStudentRecords.Rows[0].Cells[0].ColumnSpan = dtbl.Columns.Count;
                gvStudentRecords.Rows[0].Cells[0].Text = "No Data Found ..!";
                gvStudentRecords.Rows[0].Cells[0].HorizontalAlign = HorizontalAlign.Center;
            }

        }

        protected void gvStudentRecords_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.Equals("AddNew"))
                {
                    using (SqlConnection sqlCon = new SqlConnection(connectionString))
                    {
                        sqlCon.Open();
                        string query = "insert into StudentRecords values(@Std_Name, @Std_EMail, @Std_Phone, @Std_Subjects, @Std_Marks)";
                        SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                        sqlCmd.Parameters.AddWithValue("@Std_Name", (gvStudentRecords.FooterRow.FindControl("txtStdNameFooter") as TextBox).Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Std_EMail", (gvStudentRecords.FooterRow.FindControl("txtEmailFooter") as TextBox).Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Std_Phone", (gvStudentRecords.FooterRow.FindControl("txtPhoneFooter") as TextBox).Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Std_Subjects", (gvStudentRecords.FooterRow.FindControl("txtSubjectsFooter") as TextBox).Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Std_Marks", (gvStudentRecords.FooterRow.FindControl("txtMarksFooter") as TextBox).Text.Trim());
                        sqlCmd.ExecuteNonQuery();
                        PopulateGridview();
                        lblSuccessMessage.Text = "New Record Added";
                        lblErrorMessage.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                lblSuccessMessage.Text = "";
                lblErrorMessage.Text = ex.Message;
            }
        }

        protected void gvStudentRecords_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvStudentRecords.EditIndex = e.NewEditIndex;
            PopulateGridview();
        }

        protected void gvStudentRecords_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvStudentRecords.EditIndex = -1;
            PopulateGridview();
        }

        protected void gvStudentRecords_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    sqlCon.Open();
                    string query = "StdName=@Std_Name, Email=@Std_EMail, Phone=@Std_Phone, Subjects=@Std_Subjects, Marks=@Std_Marks WHERE StdId=@ID";
                    SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                    sqlCmd.Parameters.AddWithValue("@Std_Name", (gvStudentRecords.Rows[e.RowIndex].FindControl("txtFirstName") as TextBox).Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Std_EMail", (gvStudentRecords.Rows[e.RowIndex].FindControl("txtLastName") as TextBox).Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Std_Phone", (gvStudentRecords.Rows[e.RowIndex].FindControl("txtContact") as TextBox).Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Std_Subject", (gvStudentRecords.Rows[e.RowIndex].FindControl("txtEmail") as TextBox).Text.Trim());
                     sqlCmd.Parameters.AddWithValue("@Std_Marks", (gvStudentRecords.Rows[e.RowIndex].FindControl("txtEmail") as TextBox).Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@ID",Convert.ToInt32(gvStudentRecords.DataKeys[e.RowIndex].Value.ToString()));
                    sqlCmd.ExecuteNonQuery();
                    gvStudentRecords.EditIndex = -1;
                    PopulateGridview();
                    lblSuccessMessage.Text = "Selected Record Updated";
                    lblErrorMessage.Text = "";
                }
            }
            catch (Exception ex)
            {
                lblSuccessMessage.Text = "";
                lblErrorMessage.Text = ex.Message;
            }
        }

        protected void gvStudentRecords_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    sqlCon.Open();
                    string query = "delete from StudentRecords where StdId=@StdId";
                    SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                    sqlCmd.Parameters.AddWithValue("@StdId", Convert.ToInt32(gvStudentRecords.DataKeys[e.RowIndex].Value.ToString()));
                    sqlCmd.ExecuteNonQuery();
                    PopulateGridview();
                    lblSuccessMessage.Text = "Selected Record Deleted";
                    lblErrorMessage.Text = "";
                }
            }
            catch (Exception ex)
            {
                lblSuccessMessage.Text = "";
                lblErrorMessage.Text = ex.Message;
            }
        }
    }
}